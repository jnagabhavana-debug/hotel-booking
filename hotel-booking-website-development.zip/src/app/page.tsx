import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { reviews, rooms } from "@/db/schema";
import { ensureDb } from "@/db/setup";
import { BookingProvider } from "@/components/BookingContext";
import BookingSection from "@/components/BookingSection";
import Facilities from "@/components/Facilities";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import ManageBooking from "@/components/ManageBooking";
import Navbar from "@/components/Navbar";
import Pricing from "@/components/Pricing";
import Reviews from "@/components/Reviews";
import Rooms from "@/components/Rooms";

export const dynamic = "force-dynamic";

export default async function Home() {
  await ensureDb();

  const [roomRows, ratingRows, reviewRows] = await Promise.all([
    db.select().from(rooms).orderBy(asc(rooms.pricePerNight)),
    db
      .select({
        roomId: reviews.roomId,
        avg: sql<number>`avg(${reviews.rating})::float`,
        count: sql<number>`count(*)::int`,
      })
      .from(reviews)
      .groupBy(reviews.roomId),
    db
      .select({
        id: reviews.id,
        name: reviews.name,
        location: reviews.location,
        rating: reviews.rating,
        comment: reviews.comment,
        createdAt: reviews.createdAt,
        roomName: rooms.name,
      })
      .from(reviews)
      .leftJoin(rooms, eq(reviews.roomId, rooms.id))
      .orderBy(desc(reviews.createdAt))
      .limit(100),
  ]);

  const ratingMap = new Map(ratingRows.map((r) => [r.roomId, r]));
  const roomCards = roomRows.map((r) => {
    const rating = ratingMap.get(r.id);
    return {
      id: r.id,
      name: r.name,
      category: r.category,
      description: r.description,
      pricePerNight: r.pricePerNight,
      capacity: r.capacity,
      sizeSqm: r.sizeSqm,
      bedType: r.bedType,
      view: r.view,
      image: r.image,
      amenities: r.amenities,
      avgRating: rating ? Number(rating.avg) : null,
      reviewCount: rating?.count ?? 0,
    };
  });

  const summaries = roomRows.map((r) => ({
    id: r.id,
    name: r.name,
    category: r.category,
    pricePerNight: r.pricePerNight,
    capacity: r.capacity,
    image: r.image,
  }));

  const priceRows = roomRows.map((r) => ({
    id: r.id,
    name: r.name,
    category: r.category,
    pricePerNight: r.pricePerNight,
    capacity: r.capacity,
    sizeSqm: r.sizeSqm,
    breakfast: r.pricePerNight >= 300,
  }));

  const reviewItems = reviewRows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));
  const totalCount = reviewItems.length;
  const avgRating = totalCount ? reviewItems.reduce((s, r) => s + r.rating, 0) / totalCount : 5;

  return (
    <BookingProvider rooms={summaries}>
      <Navbar />
      <main>
        <Hero avgRating={avgRating} reviewCount={totalCount} />
        <Rooms rooms={roomCards} />
        <Facilities />
        <Pricing rooms={priceRows} />
        <Reviews initial={reviewItems} />
        <BookingSection />
        <ManageBooking />
      </main>
      <Footer />
    </BookingProvider>
  );
}
