import { ensureDb } from "@/db/setup";
import { priceBreakdown, unitsAvailable, validateDates } from "@/lib/booking";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const roomId = Number(url.searchParams.get("roomId"));
  const checkIn = url.searchParams.get("checkIn");
  const checkOut = url.searchParams.get("checkOut");

  if (!Number.isInteger(roomId) || roomId < 1) {
    return Response.json({ error: "Please select a room." }, { status: 400 });
  }
  const dates = validateDates(checkIn, checkOut);
  if (!dates.ok) return Response.json({ error: dates.error }, { status: 400 });

  const result = await unitsAvailable(roomId, checkIn!, checkOut!);
  if (!result) return Response.json({ error: "Room not found." }, { status: 404 });

  return Response.json({
    available: result.available,
    nights: dates.nights,
    pricePerNight: result.room.pricePerNight,
    ...priceBreakdown(result.room.pricePerNight, dates.nights),
  });
}
