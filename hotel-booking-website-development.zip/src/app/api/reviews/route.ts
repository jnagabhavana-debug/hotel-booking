import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { reviews, rooms } from "@/db/schema";
import { ensureDb } from "@/db/setup";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureDb();
  const rows = await db
    .select({
      id: reviews.id,
      name: reviews.name,
      location: reviews.location,
      rating: reviews.rating,
      comment: reviews.comment,
      createdAt: reviews.createdAt,
      roomName: rooms.name,
    })
    .from(reviews)
    .leftJoin(rooms, eq(reviews.roomId, rooms.id))
    .orderBy(desc(reviews.createdAt))
    .limit(50);
  return Response.json({ reviews: rows });
}

export async function POST(req: Request) {
  await ensureDb();
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 120) : "";
  const location = typeof body.location === "string" ? body.location.trim().slice(0, 120) : "";
  const comment = typeof body.comment === "string" ? body.comment.trim().slice(0, 1000) : "";
  const rating = Number(body.rating);
  const roomIdNum = Number(body.roomId);
  const roomId = Number.isInteger(roomIdNum) && roomIdNum > 0 ? roomIdNum : null;

  if (name.length < 2) return Response.json({ error: "Please enter your name." }, { status: 400 });
  if (!Number.isInteger(rating) || rating < 1 || rating > 5)
    return Response.json({ error: "Rating must be between 1 and 5." }, { status: 400 });
  if (comment.length < 10) return Response.json({ error: "Review should be at least 10 characters." }, { status: 400 });

  let roomName: string | null = null;
  if (roomId) {
    const [room] = await db.select({ name: rooms.name }).from(rooms).where(eq(rooms.id, roomId)).limit(1);
    if (!room) return Response.json({ error: "Room not found." }, { status: 400 });
    roomName = room.name;
  }

  const [review] = await db
    .insert(reviews)
    .values({ name, location: location || null, rating, comment, roomId })
    .returning();

  return Response.json({ review: { ...review, roomName } }, { status: 201 });
}
