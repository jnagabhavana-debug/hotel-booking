import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, rooms } from "@/db/schema";
import { ensureDb } from "@/db/setup";
import { generateReference, priceBreakdown, unitsAvailable, validateDates } from "@/lib/booking";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function str(v: unknown, max: number) {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

export async function POST(req: Request) {
  await ensureDb();
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }

  const roomId = Number(body.roomId);
  const guestName = str(body.guestName, 120);
  const email = str(body.email, 160).toLowerCase();
  const phone = str(body.phone, 40);
  const specialRequests = str(body.specialRequests, 1000);
  const guests = Number(body.guests);
  const checkIn = str(body.checkIn, 10);
  const checkOut = str(body.checkOut, 10);

  if (!Number.isInteger(roomId) || roomId < 1) return Response.json({ error: "Please select a room." }, { status: 400 });
  if (guestName.length < 2) return Response.json({ error: "Please enter your full name." }, { status: 400 });
  if (!EMAIL_RE.test(email)) return Response.json({ error: "Please enter a valid email address." }, { status: 400 });
  if (!Number.isInteger(guests) || guests < 1) return Response.json({ error: "Please enter number of guests." }, { status: 400 });

  const dates = validateDates(checkIn, checkOut);
  if (!dates.ok) return Response.json({ error: dates.error }, { status: 400 });

  const avail = await unitsAvailable(roomId, checkIn, checkOut);
  if (!avail) return Response.json({ error: "Room not found." }, { status: 404 });
  if (guests > avail.room.capacity) {
    return Response.json(
      { error: `${avail.room.name} accommodates up to ${avail.room.capacity} guests.` },
      { status: 400 },
    );
  }
  if (avail.available < 1) {
    return Response.json({ error: "Sorry, this room is fully booked for those dates." }, { status: 409 });
  }

  const { total } = priceBreakdown(avail.room.pricePerNight, dates.nights);
  const [booking] = await db
    .insert(bookings)
    .values({
      reference: generateReference(),
      roomId,
      guestName,
      email,
      phone: phone || null,
      checkIn,
      checkOut,
      guests,
      nights: dates.nights,
      totalPrice: total,
      specialRequests: specialRequests || null,
    })
    .returning();

  return Response.json({ booking: { ...booking, roomName: avail.room.name } }, { status: 201 });
}

/** Look up bookings by email (and optional reference). */
export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const email = (url.searchParams.get("email") ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return Response.json({ error: "Please enter a valid email." }, { status: 400 });

  const rows = await db
    .select({
      id: bookings.id,
      reference: bookings.reference,
      checkIn: bookings.checkIn,
      checkOut: bookings.checkOut,
      guests: bookings.guests,
      nights: bookings.nights,
      totalPrice: bookings.totalPrice,
      status: bookings.status,
      roomName: rooms.name,
      image: rooms.image,
    })
    .from(bookings)
    .innerJoin(rooms, eq(bookings.roomId, rooms.id))
    .where(eq(bookings.email, email))
    .orderBy(desc(bookings.createdAt))
    .limit(20);

  return Response.json({ bookings: rows });
}

/** Cancel a booking: requires reference + email. */
export async function PATCH(req: Request) {
  await ensureDb();
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }
  const reference = str(body.reference, 20).toUpperCase();
  const email = str(body.email, 160).toLowerCase();
  const [updated] = await db
    .update(bookings)
    .set({ status: "cancelled" })
    .where(and(eq(bookings.reference, reference), eq(bookings.email, email)))
    .returning({ id: bookings.id });
  if (!updated) return Response.json({ error: "Booking not found." }, { status: 404 });
  return Response.json({ ok: true });
}
