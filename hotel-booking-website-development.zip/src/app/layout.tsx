import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Azure Haven Resort & Spa — Luxury Seaside Hotel",
  description:
    "Book your stay at Azure Haven Resort & Spa. Explore rooms and suites, world-class facilities, transparent prices and guest reviews.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-stone-50 text-slate-800 antialiased">{children}</body>
    </html>
  );
}
