"use client";

import { useBooking } from "./BookingContext";

type PriceRow = {
  id: number;
  name: string;
  category: string;
  pricePerNight: number;
  capacity: number;
  sizeSqm: number;
  breakfast: boolean;
};

export default function Pricing({ rooms }: { rooms: PriceRow[] }) {
  const { selectRoom } = useBooking();
  return (
    <section id="pricing" className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gold-600">Prices</p>
        <h2 className="mt-3 font-serif text-4xl text-ink-900 sm:text-5xl">Transparent rates, no surprises</h2>
        <p className="mt-4 text-stone-600">
          Best rate guaranteed when you book direct. Prices are per room, per night, before 12% local taxes.
        </p>
      </div>

      <div className="mt-12 overflow-x-auto rounded-2xl bg-white shadow-sm ring-1 ring-stone-200">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="bg-stone-100 text-xs uppercase tracking-wider text-stone-500">
            <tr>
              <th className="px-6 py-4">Room</th>
              <th className="px-6 py-4">Guests</th>
              <th className="px-6 py-4">Size</th>
              <th className="px-6 py-4">Breakfast</th>
              <th className="px-6 py-4">Weekly (7 nights)</th>
              <th className="px-6 py-4 text-right">Per night</th>
              <th className="px-6 py-4" />
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {rooms.map((r) => (
              <tr key={r.id} className="transition hover:bg-stone-50">
                <td className="px-6 py-4">
                  <div className="font-serif text-lg text-ink-900">{r.name}</div>
                  <div className="text-xs text-stone-500">{r.category}</div>
                </td>
                <td className="px-6 py-4">{r.capacity}</td>
                <td className="px-6 py-4">{r.sizeSqm} m²</td>
                <td className="px-6 py-4">
                  {r.breakfast ? (
                    <span className="text-emerald-600">✓ Included</span>
                  ) : (
                    <span className="text-stone-500">+$24 / guest</span>
                  )}
                </td>
                <td className="px-6 py-4">
                  <span className="text-stone-400 line-through">${(r.pricePerNight * 7).toLocaleString()}</span>{" "}
                  <span className="font-semibold text-emerald-700">
                    ${Math.round(r.pricePerNight * 7 * 0.9).toLocaleString()}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <span className="font-serif text-2xl text-ink-900">${r.pricePerNight}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button
                    onClick={() => selectRoom(r.id)}
                    className="rounded-full border border-ink-900 px-4 py-2 text-xs font-semibold text-ink-900 transition hover:bg-ink-900 hover:text-white"
                  >
                    Select
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[
          ["🎁", "Stay 7+ nights", "Save 10% on weekly stays — ask our reservations team at check-in."],
          ["🔄", "Free cancellation", "Cancel online up to 48 hours before arrival for a full refund."],
          ["💳", "Pay at the hotel", "No prepayment needed. Your booking is confirmed instantly."],
        ].map(([icon, title, text]) => (
          <div key={title} className="flex gap-4 rounded-2xl bg-gold-300/25 p-5">
            <span className="text-2xl">{icon}</span>
            <div>
              <h3 className="font-semibold text-ink-900">{title}</h3>
              <p className="text-sm text-stone-600">{text}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
