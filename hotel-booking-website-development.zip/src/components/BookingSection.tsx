"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { addDays, isoDate, useBooking } from "./BookingContext";

type Quote = { available: number; nights: number; pricePerNight: number; subtotal: number; taxes: number; total: number };
type Confirmed = {
  reference: string;
  roomName: string;
  guestName: string;
  email: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  guests: number;
  totalPrice: number;
};

function fmt(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}

const inputCls =
  "w-full rounded-xl border border-stone-300 bg-white px-4 py-3 text-ink-900 outline-none transition focus:border-gold-500 focus:ring-2 focus:ring-gold-300/50";

export default function BookingSection() {
  const { rooms, roomId, checkIn, checkOut, guests, update } = useBooking();
  const room = rooms.find((r) => r.id === roomId) ?? null;
  const today = isoDate(new Date());

  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [loadingQuote, setLoadingQuote] = useState(false);

  const [details, setDetails] = useState({ guestName: "", email: "", phone: "", specialRequests: "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState<Confirmed | null>(null);

  useEffect(() => {
    if (!roomId || !checkIn || !checkOut) return;
    const ctrl = new AbortController();
    const t = setTimeout(async () => {
      setLoadingQuote(true);
      try {
        const res = await fetch(`/api/availability?roomId=${roomId}&checkIn=${checkIn}&checkOut=${checkOut}`, {
          signal: ctrl.signal,
        });
        const data = await res.json();
        if (!res.ok) {
          setQuote(null);
          setQuoteError(data.error ?? "Unable to check availability.");
        } else {
          setQuote(data);
          setQuoteError(null);
        }
      } catch {
        /* aborted */
      } finally {
        if (!ctrl.signal.aborted) setLoadingQuote(false);
      }
    }, 250);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [roomId, checkIn, checkOut]);

  const tooManyGuests = room ? guests > room.capacity : false;
  const canBook = !!quote && quote.available > 0 && !tooManyGuests && !quoteError;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roomId, checkIn, checkOut, guests, ...details }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Booking failed.");
      setConfirmed(data.booking);
      setDetails({ guestName: "", email: "", phone: "", specialRequests: "" });
      document.getElementById("booking")?.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Booking failed.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section id="booking" className="relative overflow-hidden bg-gradient-to-br from-ink-900 via-ink-800 to-ink-700 py-24">
      <div className="pointer-events-none absolute -right-40 -top-40 h-96 w-96 rounded-full bg-gold-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center text-white">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gold-400">Reservations</p>
          <h2 className="mt-3 font-serif text-4xl sm:text-5xl">Book your stay</h2>
          <p className="mt-4 text-white/70">Instant confirmation · No prepayment · Free cancellation up to 48 hours</p>
        </div>

        {confirmed ? (
          <div className="mx-auto mt-12 max-w-2xl rounded-3xl bg-white p-8 text-center shadow-2xl sm:p-10">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-100 text-3xl text-emerald-600">✓</div>
            <h3 className="mt-5 font-serif text-3xl text-ink-900">Your booking is confirmed!</h3>
            <p className="mt-2 text-stone-600">
              Thank you, {confirmed.guestName}. A confirmation has been noted for <strong>{confirmed.email}</strong>.
            </p>
            <div className="mt-6 inline-block rounded-xl border-2 border-dashed border-gold-500 px-6 py-3">
              <div className="text-xs uppercase tracking-wider text-stone-500">Booking reference</div>
              <div className="font-mono text-2xl font-bold tracking-widest text-ink-900">{confirmed.reference}</div>
            </div>
            <dl className="mt-8 grid grid-cols-2 gap-4 text-left text-sm">
              <div className="rounded-xl bg-stone-50 p-4">
                <dt className="text-stone-500">Room</dt>
                <dd className="font-semibold text-ink-900">{confirmed.roomName}</dd>
              </div>
              <div className="rounded-xl bg-stone-50 p-4">
                <dt className="text-stone-500">Guests</dt>
                <dd className="font-semibold text-ink-900">{confirmed.guests}</dd>
              </div>
              <div className="rounded-xl bg-stone-50 p-4">
                <dt className="text-stone-500">Check-in</dt>
                <dd className="font-semibold text-ink-900">{fmt(confirmed.checkIn)}</dd>
              </div>
              <div className="rounded-xl bg-stone-50 p-4">
                <dt className="text-stone-500">Check-out</dt>
                <dd className="font-semibold text-ink-900">{fmt(confirmed.checkOut)}</dd>
              </div>
            </dl>
            <div className="mt-6 flex items-center justify-between rounded-xl bg-ink-900 px-5 py-4 text-white">
              <span>
                Total for {confirmed.nights} {confirmed.nights === 1 ? "night" : "nights"} (incl. taxes)
              </span>
              <span className="font-serif text-2xl text-gold-300">${confirmed.totalPrice.toLocaleString()}</span>
            </div>
            <button
              onClick={() => setConfirmed(null)}
              className="mt-6 text-sm font-semibold text-gold-600 underline-offset-4 hover:underline"
            >
              Make another booking
            </button>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-12 grid gap-8 lg:grid-cols-5">
            {/* Form */}
            <div className="space-y-6 rounded-3xl bg-white p-6 shadow-2xl sm:p-8 lg:col-span-3">
              <div>
                <h3 className="font-serif text-2xl text-ink-900">1. Your stay</h3>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <label className="sm:col-span-2">
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Room type</span>
                    <select
                      value={roomId ?? ""}
                      onChange={(e) => update({ roomId: Number(e.target.value) })}
                      className={inputCls}
                    >
                      {rooms.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name} — ${r.pricePerNight}/night (up to {r.capacity} guests)
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Check-in</span>
                    <input
                      type="date"
                      required
                      min={today}
                      value={checkIn}
                      onChange={(e) => {
                        const v = e.target.value;
                        update({ checkIn: v, ...(v && v >= checkOut ? { checkOut: addDays(v, 1) } : {}) });
                      }}
                      className={inputCls}
                    />
                  </label>
                  <label>
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Check-out</span>
                    <input
                      type="date"
                      required
                      min={checkIn ? addDays(checkIn, 1) : today}
                      value={checkOut}
                      onChange={(e) => update({ checkOut: e.target.value })}
                      className={inputCls}
                    />
                  </label>
                  <label className="sm:col-span-2">
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Guests</span>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => update({ guests: Math.max(1, guests - 1) })}
                        className="grid h-11 w-11 place-items-center rounded-full border border-stone-300 text-xl text-ink-900 hover:border-ink-900"
                      >
                        −
                      </button>
                      <span className="w-20 text-center font-semibold text-ink-900">
                        {guests} {guests === 1 ? "guest" : "guests"}
                      </span>
                      <button
                        type="button"
                        onClick={() => update({ guests: Math.min(6, guests + 1) })}
                        className="grid h-11 w-11 place-items-center rounded-full border border-stone-300 text-xl text-ink-900 hover:border-ink-900"
                      >
                        +
                      </button>
                    </div>
                    {tooManyGuests && room && (
                      <p className="mt-2 text-sm text-red-600">
                        {room.name} fits up to {room.capacity} guests — please pick a larger room.
                      </p>
                    )}
                  </label>
                </div>
              </div>

              <div>
                <h3 className="font-serif text-2xl text-ink-900">2. Guest details</h3>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <label className="sm:col-span-2">
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Full name *</span>
                    <input
                      required
                      minLength={2}
                      value={details.guestName}
                      onChange={(e) => setDetails((d) => ({ ...d, guestName: e.target.value }))}
                      placeholder="Jane Doe"
                      className={inputCls}
                    />
                  </label>
                  <label>
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Email *</span>
                    <input
                      required
                      type="email"
                      value={details.email}
                      onChange={(e) => setDetails((d) => ({ ...d, email: e.target.value }))}
                      placeholder="jane@example.com"
                      className={inputCls}
                    />
                  </label>
                  <label>
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Phone</span>
                    <input
                      type="tel"
                      value={details.phone}
                      onChange={(e) => setDetails((d) => ({ ...d, phone: e.target.value }))}
                      placeholder="+1 555 123 4567"
                      className={inputCls}
                    />
                  </label>
                  <label className="sm:col-span-2">
                    <span className="mb-1.5 block text-sm font-medium text-stone-600">Special requests</span>
                    <textarea
                      rows={3}
                      value={details.specialRequests}
                      onChange={(e) => setDetails((d) => ({ ...d, specialRequests: e.target.value }))}
                      placeholder="Late arrival, anniversary celebration, extra pillows..."
                      className={inputCls}
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Summary */}
            <aside className="h-fit overflow-hidden rounded-3xl bg-white shadow-2xl lg:sticky lg:top-24 lg:col-span-2">
              {room && (
                <div className="relative aspect-[16/9]">
                  <Image src={room.image} alt={room.name} fill sizes="(min-width:1024px) 40vw, 100vw" className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-900/80 to-transparent" />
                  <div className="absolute bottom-4 left-5 text-white">
                    <div className="text-xs uppercase tracking-wider text-gold-300">{room.category}</div>
                    <div className="font-serif text-2xl">{room.name}</div>
                  </div>
                </div>
              )}
              <div className="space-y-4 p-6">
                <div className="flex justify-between text-sm">
                  <span className="text-stone-500">Dates</span>
                  <span className="text-right font-medium text-ink-900">
                    {checkIn && checkOut ? `${fmt(checkIn)} → ${fmt(checkOut)}` : "—"}
                  </span>
                </div>

                {loadingQuote && !quote && <p className="text-sm text-stone-500">Checking availability…</p>}
                {quoteError && <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{quoteError}</p>}

                {quote && !quoteError && (
                  <>
                    <div
                      className={`rounded-lg p-3 text-sm font-medium ${
                        quote.available > 0 ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
                      }`}
                    >
                      {quote.available > 0
                        ? quote.available <= 2
                          ? `⚡ Only ${quote.available} left for these dates!`
                          : `✓ Available — ${quote.available} rooms left`
                        : "✕ Fully booked for these dates"}
                    </div>
                    <div className={`space-y-2 text-sm ${loadingQuote ? "opacity-50" : ""}`}>
                      <div className="flex justify-between">
                        <span className="text-stone-600">
                          ${quote.pricePerNight} × {quote.nights} {quote.nights === 1 ? "night" : "nights"}
                        </span>
                        <span className="text-ink-900">${quote.subtotal.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-600">Taxes &amp; fees (12%)</span>
                        <span className="text-ink-900">${quote.taxes.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between border-t border-stone-200 pt-3 text-base">
                        <span className="font-semibold text-ink-900">Total</span>
                        <span className="font-serif text-2xl text-ink-900">${quote.total.toLocaleString()}</span>
                      </div>
                    </div>
                  </>
                )}

                {error && <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}

                <button
                  type="submit"
                  disabled={!canBook || submitting}
                  className="w-full rounded-xl bg-gold-500 py-4 font-semibold text-ink-900 transition hover:bg-gold-400 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {submitting ? "Confirming…" : "Confirm Booking"}
                </button>
                <p className="text-center text-xs text-stone-500">You won&apos;t be charged now. Pay at the hotel.</p>
              </div>
            </aside>
          </form>
        )}
      </div>
    </section>
  );
}
