const facilities = [
  { icon: "🏊", title: "Infinity Pool", text: "Heated 40m infinity pool overlooking the bay, open 7am – 10pm with poolside cabanas." },
  { icon: "💆", title: "Cliffside Spa", text: "Six treatment suites, sauna, steam room and signature ocean-mineral massages." },
  { icon: "🍽️", title: "Fine Dining", text: "Three restaurants including our Michelin-recommended seafood terrace, Salt & Ember." },
  { icon: "🏋️", title: "Fitness Centre", text: "24/7 Technogym equipment, yoga deck at sunrise and personal trainers on request." },
  { icon: "🏖️", title: "Private Beach", text: "Exclusive white-sand beach with loungers, towel service and water sports." },
  { icon: "📶", title: "Free Wi-Fi", text: "Complimentary high-speed fibre Wi-Fi throughout the resort, rooms and beach." },
  { icon: "🚗", title: "Airport Transfer", text: "Chauffeured transfers in premium vehicles, 25 minutes from the international airport." },
  { icon: "🧸", title: "Kids' Club", text: "Supervised activities for ages 4–12, babysitting and a splash pool for little ones." },
];

const extras = [
  ["Check-in", "From 3:00 PM"],
  ["Check-out", "Until 12:00 PM"],
  ["Breakfast", "6:30 – 10:30 AM"],
  ["Parking", "Free valet"],
  ["Pets", "Small pets welcome"],
  ["Front desk", "24 hours"],
];

export default function Facilities() {
  return (
    <section id="facilities" className="bg-ink-900 py-24 text-white">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid items-end gap-6 lg:grid-cols-2">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gold-400">Facilities</p>
            <h2 className="mt-3 font-serif text-4xl sm:text-5xl">Everything you need, nothing you don&apos;t</h2>
          </div>
          <p className="text-white/70 lg:text-right">
            Unwind by the pool, recharge at the spa or explore the coastline — our concierge team is on hand day and night to
            curate your perfect stay.
          </p>
        </div>

        <div className="mt-14 grid gap-px overflow-hidden rounded-2xl bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
          {facilities.map((f) => (
            <div key={f.title} className="bg-ink-900 p-7 transition hover:bg-ink-800">
              <div className="text-4xl">{f.icon}</div>
              <h3 className="mt-4 font-serif text-xl text-gold-300">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/70">{f.text}</p>
            </div>
          ))}
        </div>

        <dl className="mt-12 grid grid-cols-2 gap-6 rounded-2xl border border-white/10 p-6 sm:grid-cols-3 lg:grid-cols-6">
          {extras.map(([k, v]) => (
            <div key={k}>
              <dt className="text-xs uppercase tracking-wider text-white/50">{k}</dt>
              <dd className="mt-1 font-medium text-white">{v}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
