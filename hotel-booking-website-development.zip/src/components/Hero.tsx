"use client";

import Image from "next/image";
import { addDays, isoDate, useBooking } from "./BookingContext";
import Stars from "./Stars";

export default function Hero({ avgRating, reviewCount }: { avgRating: number; reviewCount: number }) {
  const { checkIn, checkOut, guests, update } = useBooking();
  const today = isoDate(new Date());

  return (
    <section id="top" className="relative flex min-h-[100svh] items-center overflow-hidden">
      <Image src="/images/hero.jpg" alt="Azure Haven Resort at sunset" fill priority className="object-cover" sizes="100vw" />
      <div className="absolute inset-0 bg-gradient-to-b from-ink-900/70 via-ink-900/40 to-ink-900/80" />

      <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-32 lg:px-8">
        <div className="max-w-3xl animate-fade-up">
          <p className="mb-4 inline-flex items-center gap-3 text-sm font-medium uppercase tracking-[0.3em] text-gold-300">
            <span className="h-px w-10 bg-gold-400" /> Five-Star Seaside Retreat
          </p>
          <h1 className="font-serif text-5xl leading-tight text-white sm:text-6xl lg:text-7xl">
            Where the ocean meets <em className="text-gold-400">quiet luxury</em>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-white/80">
            Thoughtfully designed rooms, a cliffside spa and award-winning dining — all a few steps from a private white-sand
            beach.
          </p>
          <div className="mt-6 flex items-center gap-3 text-white/90">
            <Stars rating={avgRating} size={18} />
            <span className="text-sm">
              <strong>{avgRating.toFixed(1)}</strong> from {reviewCount} guest reviews
            </span>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            document.getElementById("booking")?.scrollIntoView({ behavior: "smooth" });
          }}
          className="mt-12 grid gap-3 rounded-2xl bg-white/95 p-4 shadow-2xl backdrop-blur sm:grid-cols-2 lg:grid-cols-4 lg:p-5"
        >
          <label className="flex flex-col rounded-xl border border-stone-200 px-4 py-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">Check-in</span>
            <input
              type="date"
              min={today}
              value={checkIn}
              onChange={(e) => {
                const v = e.target.value;
                update({ checkIn: v, ...(v && v >= checkOut ? { checkOut: addDays(v, 1) } : {}) });
              }}
              className="bg-transparent py-1 font-medium text-ink-900 outline-none"
            />
          </label>
          <label className="flex flex-col rounded-xl border border-stone-200 px-4 py-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">Check-out</span>
            <input
              type="date"
              min={checkIn ? addDays(checkIn, 1) : today}
              value={checkOut}
              onChange={(e) => update({ checkOut: e.target.value })}
              className="bg-transparent py-1 font-medium text-ink-900 outline-none"
            />
          </label>
          <label className="flex flex-col rounded-xl border border-stone-200 px-4 py-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">Guests</span>
            <select
              value={guests}
              onChange={(e) => update({ guests: Number(e.target.value) })}
              className="bg-transparent py-1 font-medium text-ink-900 outline-none"
            >
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n} {n === 1 ? "Guest" : "Guests"}
                </option>
              ))}
            </select>
          </label>
          <button
            type="submit"
            className="rounded-xl bg-ink-900 px-6 py-4 font-semibold text-white transition hover:bg-ink-700"
          >
            Check Availability
          </button>
        </form>
      </div>
    </section>
  );
}
