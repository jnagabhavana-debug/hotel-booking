export default function Footer() {
  return (
    <footer className="bg-ink-900 text-white/70">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="font-serif text-2xl text-white">
            Azure Haven<span className="text-gold-400">.</span>
          </div>
          <p className="mt-3 text-sm">A five-star seaside resort &amp; spa where every detail is crafted for unhurried luxury.</p>
        </div>
        <div>
          <h4 className="font-semibold text-white">Contact</h4>
          <ul className="mt-3 space-y-1.5 text-sm">
            <li>📍 18 Coral Bay Drive, Azure Coast</li>
            <li>📞 +1 (555) 010-2030</li>
            <li>✉️ stay@azurehaven.com</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-white">Explore</h4>
          <ul className="mt-3 space-y-1.5 text-sm">
            <li><a href="#rooms" className="hover:text-gold-400">Rooms &amp; Suites</a></li>
            <li><a href="#facilities" className="hover:text-gold-400">Facilities</a></li>
            <li><a href="#pricing" className="hover:text-gold-400">Prices</a></li>
            <li><a href="#reviews" className="hover:text-gold-400">Guest Reviews</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-white">Reservations</h4>
          <p className="mt-3 text-sm">Open 24/7. Best rate guaranteed when booking direct.</p>
          <a
            href="#booking"
            className="mt-4 inline-block rounded-full bg-gold-500 px-5 py-2.5 text-sm font-semibold text-ink-900 hover:bg-gold-400"
          >
            Book your stay
          </a>
        </div>
      </div>
      <div className="border-t border-white/10 py-6 text-center text-xs text-white/50">
        © {new Date().getFullYear()} Azure Haven Resort &amp; Spa. All rights reserved.
      </div>
    </footer>
  );
}
