"use client";

import { useState } from "react";

type Row = {
  id: number;
  reference: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  nights: number;
  totalPrice: number;
  status: string;
  roomName: string;
};

export default function ManageBooking() {
  const [email, setEmail] = useState("");
  const [searched, setSearched] = useState<string | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function lookup(e?: React.FormEvent, addr = email) {
    e?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/bookings?email=${encodeURIComponent(addr)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Lookup failed.");
      setRows(data.bookings);
      setSearched(addr);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Lookup failed.");
    } finally {
      setLoading(false);
    }
  }

  async function cancel(reference: string) {
    if (!searched || !confirm(`Cancel booking ${reference}?`)) return;
    const res = await fetch("/api/bookings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reference, email: searched }),
    });
    if (res.ok) {
      setRows((r) => r.map((b) => (b.reference === reference ? { ...b, status: "cancelled" } : b)));
    } else {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Could not cancel booking.");
    }
  }

  return (
    <section id="manage" className="mx-auto max-w-4xl px-5 py-24 lg:px-8">
      <div className="text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gold-600">Manage</p>
        <h2 className="mt-3 font-serif text-4xl text-ink-900">Find my booking</h2>
        <p className="mt-3 text-stone-600">Enter the email you booked with to view or cancel your reservations.</p>
      </div>

      <form onSubmit={lookup} className="mx-auto mt-8 flex max-w-xl flex-col gap-3 sm:flex-row">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="flex-1 rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-gold-500"
        />
        <button
          disabled={loading}
          className="rounded-xl bg-ink-900 px-6 py-3 font-semibold text-white transition hover:bg-ink-700 disabled:opacity-60"
        >
          {loading ? "Searching…" : "Find bookings"}
        </button>
      </form>
      {error && <p className="mt-4 text-center text-sm text-red-600">{error}</p>}

      {searched && (
        <div className="mt-10 space-y-4">
          {rows.length === 0 ? (
            <p className="text-center text-stone-500">No bookings found for {searched}.</p>
          ) : (
            rows.map((b) => (
              <div
                key={b.id}
                className="flex flex-col gap-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-stone-200 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold tracking-wider text-ink-900">{b.reference}</span>
                    <span
                      className={`rounded-full px-2.5 py-0.5 text-xs font-semibold uppercase ${
                        b.status === "cancelled" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"
                      }`}
                    >
                      {b.status}
                    </span>
                  </div>
                  <div className="mt-1 font-serif text-lg text-ink-900">{b.roomName}</div>
                  <div className="text-sm text-stone-500">
                    {b.checkIn} → {b.checkOut} · {b.nights} {b.nights === 1 ? "night" : "nights"} · {b.guests}{" "}
                    {b.guests === 1 ? "guest" : "guests"}
                  </div>
                </div>
                <div className="flex items-center gap-4 sm:flex-col sm:items-end">
                  <span className="font-serif text-2xl text-ink-900">${b.totalPrice.toLocaleString()}</span>
                  {b.status !== "cancelled" && (
                    <button
                      onClick={() => cancel(b.reference)}
                      className="text-sm font-semibold text-red-600 hover:underline"
                    >
                      Cancel booking
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </section>
  );
}
