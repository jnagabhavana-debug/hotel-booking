"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";

export type RoomSummary = {
  id: number;
  name: string;
  category: string;
  pricePerNight: number;
  capacity: number;
  image: string;
};

type BookingState = {
  roomId: number | null;
  checkIn: string;
  checkOut: string;
  guests: number;
};

type Ctx = BookingState & {
  rooms: RoomSummary[];
  update: (patch: Partial<BookingState>) => void;
  selectRoom: (roomId: number) => void;
};

const BookingCtx = createContext<Ctx | null>(null);

export function isoDate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(iso: string, days: number) {
  const [y, m, d] = iso.split("-").map(Number);
  return isoDate(new Date(y, m - 1, d + days));
}

export function BookingProvider({ rooms, children }: { rooms: RoomSummary[]; children: ReactNode }) {
  const [state, setState] = useState<BookingState>(() => {
    const today = isoDate(new Date());
    return { roomId: rooms[0]?.id ?? null, checkIn: addDays(today, 1), checkOut: addDays(today, 3), guests: 2 };
  });

  const update = useCallback((patch: Partial<BookingState>) => {
    setState((s) => ({ ...s, ...patch }));
  }, []);

  const selectRoom = useCallback(
    (roomId: number) => {
      const room = rooms.find((r) => r.id === roomId);
      setState((s) => ({ ...s, roomId, guests: room ? Math.min(s.guests, room.capacity) : s.guests }));
      document.getElementById("booking")?.scrollIntoView({ behavior: "smooth" });
    },
    [rooms],
  );

  const value = useMemo(() => ({ ...state, rooms, update, selectRoom }), [state, rooms, update, selectRoom]);
  return <BookingCtx.Provider value={value}>{children}</BookingCtx.Provider>;
}

export function useBooking() {
  const ctx = useContext(BookingCtx);
  if (!ctx) throw new Error("useBooking must be used inside BookingProvider");
  return ctx;
}
