"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { useBooking } from "./BookingContext";
import Stars from "./Stars";

export type RoomCard = {
  id: number;
  name: string;
  category: string;
  description: string;
  pricePerNight: number;
  capacity: number;
  sizeSqm: number;
  bedType: string;
  view: string;
  image: string;
  amenities: string[];
  avgRating: number | null;
  reviewCount: number;
};

export default function Rooms({ rooms }: { rooms: RoomCard[] }) {
  const { selectRoom, guests } = useBooking();
  const categories = useMemo(() => ["All", ...Array.from(new Set(rooms.map((r) => r.category)))], [rooms]);
  const [active, setActive] = useState("All");
  const [fitsGuests, setFitsGuests] = useState(false);

  const visible = rooms.filter(
    (r) => (active === "All" || r.category === active) && (!fitsGuests || r.capacity >= guests),
  );

  return (
    <section id="rooms" className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gold-600">Rooms &amp; Suites</p>
        <h2 className="mt-3 font-serif text-4xl text-ink-900 sm:text-5xl">Find your perfect sanctuary</h2>
        <p className="mt-4 text-stone-600">
          From cosy queen rooms to private pool villas — every stay includes high-speed Wi-Fi, daily housekeeping and access
          to our infinity pool.
        </p>
      </div>

      <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setActive(c)}
            className={`rounded-full px-5 py-2 text-sm font-medium transition ${
              active === c
                ? "bg-ink-900 text-white shadow"
                : "border border-stone-300 bg-white text-stone-700 hover:border-ink-900"
            }`}
          >
            {c}
          </button>
        ))}
        <label className="ml-2 flex cursor-pointer items-center gap-2 text-sm text-stone-600">
          <input
            type="checkbox"
            checked={fitsGuests}
            onChange={(e) => setFitsGuests(e.target.checked)}
            className="h-4 w-4 accent-[#c9a24b]"
          />
          Fits {guests} {guests === 1 ? "guest" : "guests"}
        </label>
      </div>

      <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {visible.map((room) => (
          <article
            key={room.id}
            className="group flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-stone-200 transition hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="relative aspect-[4/3] overflow-hidden">
              <Image
                src={room.image}
                alt={room.name}
                fill
                sizes="(min-width:1024px) 33vw, (min-width:768px) 50vw, 100vw"
                className="object-cover transition duration-700 group-hover:scale-105"
              />
              <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-ink-900">
                {room.category}
              </span>
              <span className="absolute bottom-4 right-4 rounded-xl bg-ink-900/90 px-3 py-2 text-white">
                <span className="font-serif text-2xl">${room.pricePerNight}</span>
                <span className="text-xs text-white/70"> / night</span>
              </span>
            </div>

            <div className="flex flex-1 flex-col p-6">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-serif text-2xl text-ink-900">{room.name}</h3>
              </div>
              {room.avgRating !== null ? (
                <div className="mt-1 flex items-center gap-2 text-sm text-stone-500">
                  <Stars rating={room.avgRating} size={14} />
                  {room.avgRating.toFixed(1)} · {room.reviewCount} {room.reviewCount === 1 ? "review" : "reviews"}
                </div>
              ) : (
                <div className="mt-1 text-sm text-stone-400">No reviews yet</div>
              )}

              <p className="mt-3 text-sm leading-relaxed text-stone-600">{room.description}</p>

              <dl className="mt-4 grid grid-cols-2 gap-2 text-sm text-stone-700">
                <div className="flex items-center gap-2">👤 Up to {room.capacity} guests</div>
                <div className="flex items-center gap-2">📐 {room.sizeSqm} m²</div>
                <div className="flex items-center gap-2">🛏️ {room.bedType}</div>
                <div className="flex items-center gap-2">🌅 {room.view}</div>
              </dl>

              <ul className="mt-4 flex flex-wrap gap-1.5">
                {room.amenities.map((a) => (
                  <li key={a} className="rounded-full bg-stone-100 px-2.5 py-1 text-xs text-stone-600">
                    {a}
                  </li>
                ))}
              </ul>

              <div className="mt-auto pt-6">
                <button
                  onClick={() => selectRoom(room.id)}
                  className="w-full rounded-xl bg-gold-500 py-3 font-semibold text-ink-900 transition hover:bg-gold-400"
                >
                  Book this room
                </button>
              </div>
            </div>
          </article>
        ))}
        {visible.length === 0 && (
          <p className="col-span-full py-12 text-center text-stone-500">
            No rooms match these filters. Try another category.
          </p>
        )}
      </div>
    </section>
  );
}
