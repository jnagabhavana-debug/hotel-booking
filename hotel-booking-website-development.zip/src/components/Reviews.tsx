"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useBooking } from "./BookingContext";
import Stars from "./Stars";

export type ReviewItem = {
  id: number;
  name: string;
  location: string | null;
  rating: number;
  comment: string;
  createdAt: string;
  roomName: string | null;
};

export default function Reviews({ initial }: { initial: ReviewItem[] }) {
  const { rooms } = useBooking();
  const router = useRouter();
  const [reviews, setReviews] = useState(initial);
  const [showAll, setShowAll] = useState(false);
  const [form, setForm] = useState({ name: "", location: "", rating: 5, comment: "", roomId: "" });
  const [hover, setHover] = useState(0);
  const [status, setStatus] = useState<{ type: "error" | "success"; msg: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const count = reviews.length;
  const avg = count ? reviews.reduce((s, r) => s + r.rating, 0) / count : 0;
  const dist = [5, 4, 3, 2, 1].map((star) => ({ star, n: reviews.filter((r) => r.rating === star).length }));
  const shown = showAll ? reviews : reviews.slice(0, 6);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setStatus(null);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, roomId: form.roomId ? Number(form.roomId) : null }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Something went wrong.");
      setReviews((r) => [{ ...data.review, createdAt: data.review.createdAt }, ...r]);
      setForm({ name: "", location: "", rating: 5, comment: "", roomId: "" });
      setStatus({ type: "success", msg: "Thank you! Your review has been published." });
      router.refresh();
    } catch (err) {
      setStatus({ type: "error", msg: err instanceof Error ? err.message : "Something went wrong." });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section id="reviews" className="bg-stone-100 py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-gold-600">Guest Reviews</p>
          <h2 className="mt-3 font-serif text-4xl text-ink-900 sm:text-5xl">Loved by travellers worldwide</h2>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          {/* Summary */}
          <aside className="h-fit rounded-2xl bg-white p-7 shadow-sm ring-1 ring-stone-200 lg:sticky lg:top-24">
            <div className="flex items-end gap-3">
              <span className="font-serif text-6xl text-ink-900">{avg.toFixed(1)}</span>
              <div className="pb-2">
                <Stars rating={avg} size={18} />
                <p className="text-sm text-stone-500">{count} verified reviews</p>
              </div>
            </div>
            <div className="mt-6 space-y-2">
              {dist.map(({ star, n }) => (
                <div key={star} className="flex items-center gap-3 text-sm">
                  <span className="w-6 text-stone-600">{star}★</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-stone-200">
                    <div className="h-full rounded-full bg-gold-500" style={{ width: count ? `${(n / count) * 100}%` : 0 }} />
                  </div>
                  <span className="w-6 text-right text-stone-500">{n}</span>
                </div>
              ))}
            </div>

            <form onSubmit={submit} className="mt-8 space-y-3 border-t border-stone-200 pt-6">
              <h3 className="font-serif text-xl text-ink-900">Share your experience</h3>
              <div className="flex gap-1" onMouseLeave={() => setHover(0)}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    type="button"
                    key={n}
                    aria-label={`${n} stars`}
                    onMouseEnter={() => setHover(n)}
                    onClick={() => setForm((f) => ({ ...f, rating: n }))}
                    className={`text-2xl transition ${(hover || form.rating) >= n ? "text-gold-500" : "text-stone-300"}`}
                  >
                    ★
                  </button>
                ))}
              </div>
              <input
                required
                placeholder="Your name"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-gold-500"
              />
              <input
                placeholder="City, Country (optional)"
                value={form.location}
                onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
                className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-gold-500"
              />
              <select
                value={form.roomId}
                onChange={(e) => setForm((f) => ({ ...f, roomId: e.target.value }))}
                className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-gold-500"
              >
                <option value="">Room stayed in (optional)</option>
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
              <textarea
                required
                minLength={10}
                rows={4}
                placeholder="Tell us about your stay..."
                value={form.comment}
                onChange={(e) => setForm((f) => ({ ...f, comment: e.target.value }))}
                className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-gold-500"
              />
              {status && (
                <p className={`text-sm ${status.type === "error" ? "text-red-600" : "text-emerald-700"}`}>{status.msg}</p>
              )}
              <button
                disabled={submitting}
                className="w-full rounded-lg bg-ink-900 py-2.5 text-sm font-semibold text-white transition hover:bg-ink-700 disabled:opacity-60"
              >
                {submitting ? "Posting..." : "Post review"}
              </button>
            </form>
          </aside>

          {/* List */}
          <div className="lg:col-span-2">
            <div className="grid gap-5 sm:grid-cols-2">
              {shown.map((r) => (
                <figure key={r.id} className="flex flex-col rounded-2xl bg-white p-6 shadow-sm ring-1 ring-stone-200">
                  <div className="flex items-center justify-between">
                    <Stars rating={r.rating} size={15} />
                    <span className="text-xs text-stone-400">
                      {new Date(r.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
                    </span>
                  </div>
                  <blockquote className="mt-4 flex-1 text-stone-700">&ldquo;{r.comment}&rdquo;</blockquote>
                  <figcaption className="mt-5 flex items-center gap-3 border-t border-stone-100 pt-4">
                    <span className="grid h-10 w-10 place-items-center rounded-full bg-ink-900 font-semibold text-gold-300">
                      {r.name.charAt(0).toUpperCase()}
                    </span>
                    <div className="min-w-0">
                      <div className="truncate font-semibold text-ink-900">{r.name}</div>
                      <div className="truncate text-xs text-stone-500">
                        {[r.location, r.roomName].filter(Boolean).join(" · ") || "Verified guest"}
                      </div>
                    </div>
                  </figcaption>
                </figure>
              ))}
            </div>
            {reviews.length > 6 && (
              <div className="mt-8 text-center">
                <button
                  onClick={() => setShowAll((s) => !s)}
                  className="rounded-full border border-ink-900 px-6 py-2.5 text-sm font-semibold text-ink-900 transition hover:bg-ink-900 hover:text-white"
                >
                  {showAll ? "Show fewer" : `Show all ${reviews.length} reviews`}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
