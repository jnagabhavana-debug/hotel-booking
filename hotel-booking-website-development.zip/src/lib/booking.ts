import { and, eq, gt, lt, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, rooms } from "@/db/schema";

export const TAX_RATE = 0.12;

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function parseDate(value: unknown): Date | null {
  if (typeof value !== "string" || !DATE_RE.test(value)) return null;
  const d = new Date(`${value}T00:00:00Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function todayUtc(): Date {
  const n = new Date();
  return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()));
}

export function nightsBetween(a: Date, b: Date) {
  return Math.round((b.getTime() - a.getTime()) / 86_400_000);
}

export function priceBreakdown(pricePerNight: number, nights: number) {
  const subtotal = pricePerNight * nights;
  const taxes = Math.round(subtotal * TAX_RATE);
  return { subtotal, taxes, total: subtotal + taxes };
}

export type DateValidation =
  | { ok: true; checkIn: Date; checkOut: Date; nights: number }
  | { ok: false; error: string };

export function validateDates(checkInRaw: unknown, checkOutRaw: unknown): DateValidation {
  const checkIn = parseDate(checkInRaw);
  const checkOut = parseDate(checkOutRaw);
  if (!checkIn || !checkOut) return { ok: false, error: "Please choose valid check-in and check-out dates." };
  if (checkIn < todayUtc()) return { ok: false, error: "Check-in date cannot be in the past." };
  const nights = nightsBetween(checkIn, checkOut);
  if (nights < 1) return { ok: false, error: "Check-out must be at least one day after check-in." };
  if (nights > 30) return { ok: false, error: "Stays are limited to 30 nights online." };
  return { ok: true, checkIn, checkOut, nights };
}

/** Number of units of a room still free for the given date range. */
export async function unitsAvailable(roomId: number, checkIn: string, checkOut: string) {
  const [room] = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
  if (!room) return null;
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(bookings)
    .where(
      and(
        eq(bookings.roomId, roomId),
        ne(bookings.status, "cancelled"),
        lt(bookings.checkIn, checkOut),
        gt(bookings.checkOut, checkIn),
      ),
    );
  return { room, available: Math.max(0, room.totalUnits - count) };
}

export function generateReference() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "AZR-";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
