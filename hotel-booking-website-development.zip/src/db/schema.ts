import {
  date,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  description: text("description").notNull(),
  pricePerNight: integer("price_per_night").notNull(),
  capacity: integer("capacity").notNull(),
  sizeSqm: integer("size_sqm").notNull(),
  bedType: varchar("bed_type", { length: 80 }).notNull(),
  view: varchar("view", { length: 80 }).notNull(),
  image: varchar("image", { length: 255 }).notNull(),
  amenities: jsonb("amenities").$type<string[]>().notNull(),
  totalUnits: integer("total_units").notNull().default(5),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  location: varchar("location", { length: 120 }),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  roomId: integer("room_id").references(() => rooms.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  reference: varchar("reference", { length: 20 }).notNull().unique(),
  roomId: integer("room_id")
    .notNull()
    .references(() => rooms.id, { onDelete: "cascade" }),
  guestName: varchar("guest_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  checkIn: date("check_in").notNull(),
  checkOut: date("check_out").notNull(),
  guests: integer("guests").notNull(),
  nights: integer("nights").notNull(),
  totalPrice: integer("total_price").notNull(),
  specialRequests: text("special_requests"),
  status: varchar("status", { length: 20 }).notNull().default("confirmed"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Room = typeof rooms.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
