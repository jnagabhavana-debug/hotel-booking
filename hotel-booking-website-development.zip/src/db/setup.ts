import { sql } from "drizzle-orm";
import { db } from "@/db";
import { reviews, rooms } from "@/db/schema";

const seedRooms: (typeof rooms.$inferInsert)[] = [
  {
    slug: "classic-queen",
    name: "Classic Queen Room",
    category: "Standard",
    description:
      "A calm, light-filled retreat with warm oak accents, a plush queen bed and everything you need for a restful city or seaside stay.",
    pricePerNight: 129,
    capacity: 2,
    sizeSqm: 24,
    bedType: "1 Queen Bed",
    view: "Garden View",
    image: "/images/room-standard.jpg",
    amenities: ["Free Wi-Fi", "Smart TV", "Rain Shower", "Air Conditioning", "Coffee Maker"],
    totalUnits: 8,
  },
  {
    slug: "deluxe-ocean-king",
    name: "Deluxe Ocean King",
    category: "Deluxe",
    description:
      "Floor-to-ceiling windows frame the ocean from your king bed. Designed in soft sand tones with a reading lounge and deep soaking tub.",
    pricePerNight: 219,
    capacity: 2,
    sizeSqm: 36,
    bedType: "1 King Bed",
    view: "Ocean View",
    image: "/images/room-deluxe.jpg",
    amenities: ["Free Wi-Fi", "Ocean Balcony", "Soaking Tub", "Minibar", "Nespresso", "Bathrobes"],
    totalUnits: 6,
  },
  {
    slug: "family-garden",
    name: "Family Garden Room",
    category: "Family",
    description:
      "Generous space for the whole family with a king bed plus two singles, a kids' welcome kit and direct access to the garden lawn.",
    pricePerNight: 269,
    capacity: 4,
    sizeSqm: 48,
    bedType: "1 King + 2 Single Beds",
    view: "Garden View",
    image: "/images/room-family.jpg",
    amenities: ["Free Wi-Fi", "2 Smart TVs", "Kids' Kit", "Mini Fridge", "Board Games", "Blackout Blinds"],
    totalUnits: 4,
  },
  {
    slug: "executive-skyline-suite",
    name: "Executive Skyline Suite",
    category: "Suite",
    description:
      "A separate living room with velvet lounge, marble bathroom and sweeping skyline views. Includes Executive Lounge access and evening canapés.",
    pricePerNight: 389,
    capacity: 3,
    sizeSqm: 68,
    bedType: "1 King Bed + Sofa Bed",
    view: "Skyline View",
    image: "/images/room-suite.jpg",
    amenities: ["Lounge Access", "Living Room", "Marble Bath", "Butler Service", "Bose Speaker", "Welcome Champagne"],
    totalUnits: 3,
  },
  {
    slug: "private-pool-villa",
    name: "Private Pool Villa",
    category: "Villa",
    description:
      "Our most secluded escape: an open-plan villa with private plunge pool, sun deck, outdoor shower and dedicated villa host around the clock.",
    pricePerNight: 649,
    capacity: 4,
    sizeSqm: 120,
    bedType: "1 King Bed + Daybed",
    view: "Private Pool",
    image: "/images/room-villa.jpg",
    amenities: ["Private Pool", "Outdoor Shower", "Villa Host", "In-Villa Dining", "Daily Breakfast", "Airport Transfer"],
    totalUnits: 2,
  },
];

const seedReviews = [
  { name: "Sophie Laurent", location: "Paris, France", rating: 5, slug: "deluxe-ocean-king", comment: "Waking up to the ocean through those huge windows was unforgettable. Staff remembered our names from day one and the breakfast spread was superb." },
  { name: "Daniel Okafor", location: "Lagos, Nigeria", rating: 5, slug: "executive-skyline-suite", comment: "The suite was bigger than my apartment! Lounge access was a real bonus for work calls, and the canapés in the evening were a lovely touch." },
  { name: "Mei Tanaka", location: "Osaka, Japan", rating: 4, slug: "classic-queen", comment: "Spotless, quiet and very comfortable bed. Great value for the location. Only wish the gym opened a little earlier." },
  { name: "The Garcia Family", location: "Austin, USA", rating: 5, slug: "family-garden", comment: "Our kids loved the welcome kit and the garden right outside the door. Plenty of space for four of us and the kids' club was fantastic." },
  { name: "Liam & Ava", location: "Dublin, Ireland", rating: 5, slug: "private-pool-villa", comment: "Honeymoon perfection. Private pool at sunset, dinner served on our deck, and our villa host thought of everything before we did." },
  { name: "Raj Patel", location: "London, UK", rating: 4, slug: "deluxe-ocean-king", comment: "Gorgeous views and a fantastic spa. Check-in took a few minutes longer than expected but they upgraded our welcome drinks to make up for it." },
];

let setupPromise: Promise<void> | null = null;

async function runSetup() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS rooms (
      id serial PRIMARY KEY,
      slug varchar(80) NOT NULL UNIQUE,
      name varchar(120) NOT NULL,
      category varchar(40) NOT NULL,
      description text NOT NULL,
      price_per_night integer NOT NULL,
      capacity integer NOT NULL,
      size_sqm integer NOT NULL,
      bed_type varchar(80) NOT NULL,
      view varchar(80) NOT NULL,
      image varchar(255) NOT NULL,
      amenities jsonb NOT NULL,
      total_units integer NOT NULL DEFAULT 5
    )`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS reviews (
      id serial PRIMARY KEY,
      name varchar(120) NOT NULL,
      location varchar(120),
      rating integer NOT NULL,
      comment text NOT NULL,
      room_id integer REFERENCES rooms(id) ON DELETE SET NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    )`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS bookings (
      id serial PRIMARY KEY,
      reference varchar(20) NOT NULL UNIQUE,
      room_id integer NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      guest_name varchar(120) NOT NULL,
      email varchar(160) NOT NULL,
      phone varchar(40),
      check_in date NOT NULL,
      check_out date NOT NULL,
      guests integer NOT NULL,
      nights integer NOT NULL,
      total_price integer NOT NULL,
      special_requests text,
      status varchar(20) NOT NULL DEFAULT 'confirmed',
      created_at timestamptz NOT NULL DEFAULT now()
    )`);

  const existing = await db.select({ id: rooms.id }).from(rooms).limit(1);
  if (existing.length > 0) return;

  const inserted = await db
    .insert(rooms)
    .values(seedRooms)
    .onConflictDoNothing()
    .returning({ id: rooms.id, slug: rooms.slug });
  const bySlug = new Map(inserted.map((r) => [r.slug, r.id]));

  const now = Date.now();
  await db.insert(reviews).values(
    seedReviews.map((r, i) => ({
      name: r.name,
      location: r.location,
      rating: r.rating,
      comment: r.comment,
      roomId: bySlug.get(r.slug) ?? null,
      createdAt: new Date(now - (i + 1) * 1000 * 60 * 60 * 24 * 6),
    })),
  );
}

export function ensureDb(): Promise<void> {
  if (!setupPromise) {
    setupPromise = runSetup().catch((err) => {
      setupPromise = null;
      throw err;
    });
  }
  return setupPromise;
}
